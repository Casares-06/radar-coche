const BLOCKED_HOSTS = ["wallapop.com", "milanuncios.com"];

function readCurrentPage() {
  const meta = (key) => document.querySelector(`meta[property="${key}"], meta[name="${key}"]`)?.content || "";
  const records = [];
  for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      const data = JSON.parse(script.textContent);
      const visit = (value) => {
        if (!value || typeof value !== "object") return;
        if (Array.isArray(value)) return value.forEach(visit);
        records.push(value);
        if (value["@graph"]) visit(value["@graph"]);
      };
      visit(data);
    } catch { /* Un bloque JSON-LD inválido no debe impedir la captura. */ }
  }
  const typeNames = record => {
    const type = record?.["@type"] || [];
    return (Array.isArray(type) ? type : [type]).map(String).map(x => x.toLowerCase());
  };
  const product = records.find(record => typeNames(record).some(type =>
    ["car", "vehicle", "product"].some(name => type.endsWith(name)))) || {};
  const offer = Array.isArray(product.offers) ? product.offers[0] : product.offers || {};
  const brand = typeof product.brand === "object" ? product.brand?.name : product.brand;
  const rawMileage = product.mileageFromOdometer || product.mileage;
  const mileage = typeof rawMileage === "object" ? rawMileage.value : rawMileage;
  const candidate = {
    url: location.href,
    selectedText: String(window.getSelection?.() || "").slice(0, 8000),
    fields: {},
    origins: {},
  };
  const set = (key, value) => {
    if (value !== null && value !== undefined && String(value).trim()) {
      candidate.fields[key] = String(value).trim().slice(0, 200);
      candidate.origins[key] = "anuncio";
    }
  };
  set("make", brand);
  set("model", product.model);
  set("version", product.name || meta("og:title") || document.title);
  set("year", product.vehicleModelDate || product.productionDate);
  set("km", mileage);
  const price = offer.price || meta("product:price:amount");
  set("priceCash", price);
  const fuel = product.fuelType || product.vehicleEngine?.fuelType;
  set("fuel", fuel);
  return candidate;
}

chrome.action.onClicked.addListener(async tab => {
  const tabId = tab.id;
  if (!tabId) return;
  let pendingCapture;
  try {
    const url = new URL(tab.url || "");
    if (!["http:", "https:"].includes(url.protocol)) {
      throw new Error("Abre un anuncio web normal para capturarlo. Puedes añadirlo manualmente en el panel.");
    }
    if (BLOCKED_HOSTS.some(host => url.hostname === host || url.hostname.endsWith("." + host))) {
      throw new Error("La captura automática está desactivada en este portal. Puedes introducir tus propios datos manualmente.");
    }
    const results = await chrome.scripting.executeScript({ target: { tabId }, func: readCurrentPage });
    pendingCapture = results?.[0]?.result || { error: "No se pudo leer la página. Introduce los datos manualmente." };
  } catch (error) {
    pendingCapture = { error: error.message || "No se pudo leer la página. Introduce los datos manualmente." };
  }
  await chrome.storage.local.set({ pendingCapture });
  try {
    await chrome.sidePanel.open({ tabId });
  } catch {
    await chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
  }
});
